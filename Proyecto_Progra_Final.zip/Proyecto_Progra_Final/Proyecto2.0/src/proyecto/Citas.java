/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import javax.swing.JOptionPane;

/**
 * @author Pereyra
 * @author Pablo Vega
 * @author Daniel Q aka Funnyd
 */
public class Citas {

    public Barberos cBarberos[] = new Barberos[5];
    public String Dia = " ";
    public int horaCita = 0;
    public double ganancia = 0;
    public int cantidadhoras = 0;
    int cantidadCitas = 0;
    public String[][] citas = new String[10][7];
/*public void guardarBarbero() {
        // Definir los nombres de los barberos y sus horas de almuerzo por defecto
        String[] nombresBarberos = {"Barbero1", "Barbero2", "Barbero3", "Barbero4", "Barbero5"};
        int[] horasAlmuerzo = {12, 13, 14, 15, 12}; 

        for (int x = 0; x < cBarberos.length; x++) {
            Barberos barbero = new Barberos();
            barbero.Nombre_Barbero = nombresBarberos[x];
            barbero.Horario_Almuerzo = horasAlmuerzo[x];
            cBarberos[x] = barbero;
        }
    }*/
   // Funcion para Guardar Barbero
public void guardarBarbero() {
    for (int x = 0; x < cBarberos.length; x++) {
        Barberos barbero = new Barberos();
        barbero.Nombre_Barbero = JOptionPane.showInputDialog("Digite el nombre del barbero: ");

        // Validar la hora de almuerzo dentro del rango permitido
        boolean horaValida = false;
        while (!horaValida) {
            String inputHora = JOptionPane.showInputDialog("Digite la hora que sale el barbero a almorzar (horario de las 11 a las 15h): ");
            
                int hora = Integer.parseInt(inputHora);
                if (hora >= 11 && hora <= 15) {
                    barbero.Horario_Almuerzo = hora;
                    horaValida = true;
                } else {
                    JOptionPane.showMessageDialog(null, "Hora de almuerzo no válida. Debe estar entre 11 y 15 horas.");
                }
            
        }

        cBarberos[x] = barbero;
    }
}

// Funcion para Agendar Citas
public Barberos AgendarCita() {
    Barberos barbero = new Barberos();
    Clientes cliente = new Clientes();
    Calendario calendario = new Calendario();

    // Agendar Barbero
    String Nombre_Barbero = JOptionPane.showInputDialog("Digite el nombre del barbero con el que desea su cita: ");
    int indiceBarberos = -1;
    for (int i = 0; i < cBarberos.length; i++) {
        if (cBarberos[i].Nombre_Barbero.equals(Nombre_Barbero)) {
            indiceBarberos = i;
            break;
        }
    }
    if (indiceBarberos == -1) {
        JOptionPane.showMessageDialog(null, "No ha ingresado ningún barbero o el barbero no existe");
        return barbero;
    }
    barbero = cBarberos[indiceBarberos];
    cliente.Nombre = JOptionPane.showInputDialog("Digite el nombre del cliente: ");
    int Telefono = Integer.parseInt(JOptionPane.showInputDialog("Digite el teléfono del Cliente: "));
    cliente.setTelefono(Telefono);

    // Llamada a Calendario
    calendario.FechaCita();
    if (calendario.fechaCita == null) {
        return barbero;
    }
    cantidadhoras = Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad de horas que requiere el servicio: "));
    horaCita = Integer.parseInt(JOptionPane.showInputDialog("Digite la hora que quiere su Cita en un horario de las"
            + "\n8 a las 17 horas"));
    int horafinal = cantidadhoras + horaCita - 1;

    // Validar que la hora de inicio y cierre estén dentro del horario de la barbería
    if (horaCita < 8 || horafinal > 17) {
        JOptionPane.showMessageDialog(null, "La hora de inicio o cierre de la cita está fuera del horario de la barbería. Hora no válida.");
        return barbero;
    }

    // Validar la hora de almuerzo del barbero
    if (horaCita >= barbero.Horario_Almuerzo && horafinal < (barbero.Horario_Almuerzo + 1)) {
        JOptionPane.showMessageDialog(null, "La duración del servicio incluye la hora de almuerzo del barbero. Hora no disponible.");
        return barbero;
    }

    // Validar si ya hay una cita para la misma hora y día
    for (int j = 0; j < cantidadCitas; j++) {
        if (citas[j][0].equals(calendario.fechaCita) && Integer.parseInt(citas[j][1]) == horaCita && citas[j][6].equals(barbero.Nombre_Barbero)) {
            JOptionPane.showMessageDialog(null, "Ya existe una cita para el mismo día y hora. Por favor, elija otro horario.");
            return barbero;
        }
    }

    // Validar si la nueva cita se superpone con otra cita existente
    for (int j = 0; j < cantidadCitas; j++) {
        int horaCitaExistente = Integer.parseInt(citas[j][1]);
        int duracionCitaExistente = Integer.parseInt(citas[j][2]);
        int horafinalExistente = horaCitaExistente + duracionCitaExistente - 1;

        if (calendario.fechaCita.equals(citas[j][0]) &&
            ((horaCita >= horaCitaExistente && horaCita <= horafinalExistente) || (horafinal >= horaCitaExistente && horafinal <= horafinalExistente))) {
            JOptionPane.showMessageDialog(null, "La hora y duracion de servicio coincide con el de otra cita . Hora no válida.");
            return barbero;
        }
    }

    // Validar que la nueva cita no coincida con la hora de almuerzo del barbero
    if (horaCita <= barbero.Horario_Almuerzo && horafinal >= barbero.Horario_Almuerzo) {
        JOptionPane.showMessageDialog(null, "La nueva cita coincide con la hora de almuerzo del barbero. Hora no válida.");
        return barbero;
    }

    // Validar que la nueva cita no comience antes de la hora de apertura o termine después de la hora de cierre
    if (horaCita < 8 || horafinal > 17) {
        JOptionPane.showMessageDialog(null, "La nueva cita comienza antes de la hora de apertura o termina después de la hora de cierre. Hora no válida.");
        return barbero;
    }

    
    // Guardado de cita 
    citas[cantidadCitas][0] = String.valueOf(calendario.fechaCita);
    citas[cantidadCitas][1] = String.valueOf(horaCita);
    citas[cantidadCitas][2] = String.valueOf(cantidadhoras);
    citas[cantidadCitas][3] = String.valueOf(cliente.Nombre);
    citas[cantidadCitas][4] = String.valueOf(cliente.getTelefono(Telefono));
    citas[cantidadCitas][6] = String.valueOf(barbero.Nombre_Barbero);
    if (calendario.fechaCita.contains("sábado") || calendario.fechaCita.contains("domingo")) {
        this.ganancia = 3000 * cantidadhoras * 1.13;
        JOptionPane.showMessageDialog(null, "La cita tiene un valor de 3000 colones por hora más 13% de IVA");
        JOptionPane.showMessageDialog(null, "La fecha de su cita es: " + calendario.fechaCita);
        JOptionPane.showMessageDialog(null, "La cita ha sido agendada" + "\nEl costo de la cita es de: " + Math.round(ganancia));
    } else {
        this.ganancia = 2500 * cantidadhoras * 1.13;
        JOptionPane.showMessageDialog(null, "La cita tiene un valor de 2500 colones más 13% de IVA");
        JOptionPane.showMessageDialog(null, "La fecha de su cita es: " + calendario.fechaCita + " a las " + horaCita + ":00");
        JOptionPane.showMessageDialog(null, "La cita ha sido agendada" + "\nEl costo de la cita es de: " + Math.round(ganancia));
    }
    citas[cantidadCitas][5] = String.valueOf(ganancia);
    cantidadCitas++;

    return barbero;
}

    //Metodo para consultar citas
    public void MostrarCitas(String Nombre_Barbero) {
        int indiceBarberos = -1;
        for (int i = 0; i < cBarberos.length; i++) {
            if (cBarberos[i].Nombre_Barbero.equals(Nombre_Barbero)) {
                indiceBarberos = i;
                break;
            }
        }
        if (indiceBarberos == -1) {
            JOptionPane.showMessageDialog(null, "No ha ingresado ningún barbero o el barbero no existe");
            return;
        } else if (cBarberos[indiceBarberos].Nombre_Barbero.equals(Nombre_Barbero)) {
            String ConsultarDia = JOptionPane.showInputDialog("Digite el día exacto que desea consultar: "
                    + "\n             (dia fecha mes año)");
            String mensaje = "Citas del día " + ConsultarDia + " para el barbero " + Nombre_Barbero + ":\n";

            boolean[] horasOcupadas = new boolean[18];
            double gananciaTotal = 0;
            for (int j = 0; j < cantidadCitas; j++) {
                if (citas[j][0].equals(ConsultarDia) && citas[j][6].equals(Nombre_Barbero)) {
                    int horaCita = Integer.parseInt(citas[j][1]);
                    int duracionCita = Integer.parseInt(citas[j][2]);
                    String NombreCliente = (citas[j][3]);
                    int telefonoCliente = Integer.parseInt(citas[j][4]);
                    double gananciaCita = Double.parseDouble(citas[j][5]);
                    gananciaTotal += gananciaCita;
                    for (int k = horaCita; k < horaCita + duracionCita; k++) {
                        horasOcupadas[k] = true;
                    }
                    mensaje += "Hora: " + horaCita + " - " + (horaCita + duracionCita)
                            + ", Cliente: " + NombreCliente + ", Teléfono: " + telefonoCliente + "\n";
                }
            }

            for (int k = 8; k <= 17; k++) {
                if (!horasOcupadas[k]) {
                    if (k != cBarberos[indiceBarberos].Horario_Almuerzo) {
                        mensaje += "Hora: " + k + ":00, VACIO\n";
                    } else {
                        mensaje += "Hora: " + k + ":00, ALMUERZO\n";
                    }
                }
            }

            mensaje += "\nGanancia total del día: " + Math.round(gananciaTotal);
            JOptionPane.showMessageDialog(null, mensaje);
        }
    }

    //Metodo para eliminar citas
    public void eliminarCitas(String Nombre_Barbero) {
        int indiceBarberos = -1;
        for (int i = 0; i < cBarberos.length; i++) {
            if (cBarberos[i].Nombre_Barbero.equals(Nombre_Barbero)) {
                indiceBarberos = i;
                break;
            }
        }

        if (indiceBarberos == -1) {
            JOptionPane.showMessageDialog(null, "No ha ingresado ningún barbero o el barbero no existe");
            return;
        }

        String consultarCliente = JOptionPane.showInputDialog("¿De cuál cliente desea eliminar la cita?");
        int citasEliminadas = 0;

        for (int x = 0; x < cantidadCitas; x++) {
            if (citas[x][3].equals(consultarCliente) && citas[x][6].equals(Nombre_Barbero)) {
                String consultarDia = JOptionPane.showInputDialog("Digite la fecha de la cita (dia fecha mes año): ");
                int horaCita = Integer.parseInt(JOptionPane.showInputDialog("Digite la hora de la cita a eliminar: "));

                for (int e = 0; e < cantidadCitas; e++) {
                    if (Integer.parseInt(citas[e][1]) == horaCita && citas[e][3].equals(consultarCliente) && citas[e][0].equals(consultarDia) && citas[e][6].equals(Nombre_Barbero)) {
                        citas[e][0] = "";
                        citas[e][1] = "";
                        citas[e][2] = "";
                        citas[e][3] = "";
                        citas[e][4] = "";
                        citas[e][5] = "";
                        citas[e][6] = "";
                        JOptionPane.showMessageDialog(null, "La cita ha sido eliminada");
                        citasEliminadas++;
                        break;

                    }
                }
                break;
            }
        }

        if (citasEliminadas == 0) {
            JOptionPane.showMessageDialog(null, "No se encontraron citas para el cliente especificado");
        }
    }
}
