Grupo #4 Conformado por:
Carlos Pereyra Cerdas
Daniel Quesada Aguilar
Keylin Sibaja Quiros
Jose Pablo Vega Valverde
