/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto;

/**
 *
 * @author dques
 */
public class Barberos {
    public String nombreBarbero="";
    public int almuerzoBarbero=0;
    
    public String getNombreBarbero(){
        return nombreBarbero;
    }
    
    public void setBarbero(String nombre, int almuerzo){
        this.nombreBarbero=nombre;
        this.almuerzoBarbero=almuerzo;
        
}
    
}
